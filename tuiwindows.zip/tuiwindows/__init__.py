from .functions import window,cls,textInput,msgBox
__version__ = "1.0.1"